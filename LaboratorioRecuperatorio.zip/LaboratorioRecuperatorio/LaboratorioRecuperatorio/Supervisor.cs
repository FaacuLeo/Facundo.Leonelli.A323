﻿using System;

public class Supervisor : Empleado
{
    private static float valorHora = 1025.50F;

    private Supervisor() : this("n/a")
    {
    }

    private Supervisor(string legajo) : this(legajo, "n/a", new TimeSpan(09, 00, 00))
    {
    }

    public Supervisor(string legajo, string nombre, TimeSpan horaIngreso) : base(legajo, nombre, horaIngreso)
    {
    }

    public float ValorHora
    {
        get { return valorHora; }
        set { if (value > 0) valorHora = value; }
    }

    public override string EmitirFactura()
    {
        return $"Factura de: {ToString()}\nImporte a facturar: {Facturar()}";
    }

    protected override double Facturar()
    {
        return (HoraEgreso - HoraIngreso).TotalHours * valorHora;
    }

    public static implicit operator Supervisor(string legajo)
    {
        return new Supervisor(legajo);
    }

    public override string ToString()
    {
        return $"{this.GetType().Name} - {Legajo} - {Nombre}";
    }
}
