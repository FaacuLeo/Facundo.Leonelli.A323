﻿using System;

public abstract class Empleado
{
    protected TimeSpan horaEgreso;
    protected TimeSpan horaIngreso;
    protected string legajo;
    protected string nombre;

    public TimeSpan HoraEgreso
    {
        get { return horaEgreso; }
        set { horaEgreso = ValidaHoraEgreso(value); }
    }

    public TimeSpan HoraIngreso
    {
        get { return horaIngreso; }
    }

    public string Legajo
    {
        get { return legajo; }
    }

    public string Nombre
    {
        get { return nombre; }
    }

    protected Empleado(string legajo, string nombre, TimeSpan horaIngreso)
    {
        this.legajo = legajo;
        this.nombre = nombre;
        this.horaIngreso = horaIngreso;
    }

    private TimeSpan ValidaHoraEgreso(TimeSpan horaEgreso)
    {
        return horaEgreso > horaIngreso ? horaEgreso : DateTime.Now.TimeOfDay;
    }

    public abstract string EmitirFactura();
    protected abstract double Facturar();

    public static bool operator ==(Empleado emp1, Empleado emp2)
    {
        return emp1.legajo == emp2.legajo;
    }

    public static bool operator !=(Empleado emp1, Empleado emp2)
    {
        return !(emp1 == emp2);
    }
}
