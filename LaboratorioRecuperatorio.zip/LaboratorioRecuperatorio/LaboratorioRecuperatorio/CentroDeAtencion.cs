﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class CentroDeAtencion
{
    private int cantRacsPorSuper;
    private List<Empleado> empleados;
    private string nombre;

    public List<Empleado> Empleados
    {
        get { return empleados; }
    }

    public string Nombre
    {
        get { return nombre; }
    }

    public CentroDeAtencion(string nombre, int cantRacsPorSuper)
    {
        this.nombre = nombre;
        this.cantRacsPorSuper = cantRacsPorSuper;
        this.empleados = new List<Empleado>();
    }

    private bool ValidaCantidadDeRacs()
    {
        int numRacs = 0;
        int numSupervisores = 0;
        foreach (var empleado in empleados)
        {
            if (empleado is Rac)
            {
                numRacs++;
            }
            else if (empleado is Supervisor)
            {
                numSupervisores++;
            }
        }
        return numRacs / cantRacsPorSuper > numSupervisores;
    }

    public static bool operator ==(CentroDeAtencion c, Empleado e)
    {
        return c.empleados.Contains(e);
    }

    public static bool operator !=(CentroDeAtencion c, Empleado e)
    {
        return !(c == e);
    }

    public static bool operator +(CentroDeAtencion c, Empleado e)
    {
        if (c.empleados.Contains(e))
        {
            return false;
        }
        if (e is Supervisor)
        {
            if (!c.ValidaCantidadDeRacs())
            {
                return false;
            }
        }
        c.empleados.Add(e);
        return true;
    }

    public static string operator -(CentroDeAtencion c, Empleado e)
    {
        if (!c.empleados.Contains(e))
        {
            return "Empleado no encontrado";
        }
        e.HoraEgreso = DateTime.Now.TimeOfDay;
        c.empleados.Remove(e);
        return e.EmitirFactura();
    }

    public string ImprimirNomina()
    {
        StringBuilder sb = new StringBuilder();
        foreach (var empleado in empleados)
        {
            sb.AppendLine(empleado.ToString());
        }
        return sb.ToString();
    }
}
