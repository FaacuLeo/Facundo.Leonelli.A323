﻿using LaboratorioRecuperatorio;
using System;

public class Rac : Empleado
{
    // Atributos privados
    private EGrupo grupo;
    private static double valorHora = 875.90;

    // Propiedades de solo lectura y con validación en el setter
    public EGrupo Grupo
    {
        get { return grupo; }
    }

    public static double ValorHora
    {
        get { return valorHora; }
        set { if (value > 0) valorHora = value; }
    }

    // Constructor privado sin parámetros
    private Rac() : this("n/a", "n/a", new TimeSpan(09, 00, 00), EGrupo.CALL_IN) { }

    // Constructor público con parámetros básicos
    public Rac(string legajo, string nombre, TimeSpan horaIngreso)
        : this(legajo, nombre, horaIngreso, EGrupo.CALL_IN) { }

    // Constructor público con todos los parámetros
    public Rac(string legajo, string nombre, TimeSpan horaIngreso, EGrupo grupo)
        : base(legajo, nombre, horaIngreso)
    {
        this.grupo = grupo;
    }

    // Método privado para calcular el bono de grupo
    private double CalculaBonoDeGrupo()
    {
        switch (grupo)
        {
            case EGrupo.CALL_OUT:
                return 0.1;
            case EGrupo.RRSS:
                return 0.2;
            default:
                return 0;
        }
    }

    // Método EmitirFactura
    public override string EmitirFactura()
    {
        return $"Factura de: {ToString()}\nImporte a facturar: {Facturar()}";
    }

    // Método Facturar protegido
    protected override double Facturar()
    {
        double bono = CalculaBonoDeGrupo();
        double valorHoraConBono = valorHora * (1 + bono);
        return (HoraEgreso - HoraIngreso).TotalHours * valorHoraConBono;
    }

    // Sobrescribir el método ToString
    public override string ToString()
    {
        return $"{this.GetType().Name} - {grupo} - {Legajo} - {Nombre}";
    }
}
