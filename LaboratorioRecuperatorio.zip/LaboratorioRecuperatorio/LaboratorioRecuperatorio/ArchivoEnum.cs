﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaboratorioRecuperatorio
{
     public enum EGrupo
        {
            CALL_IN,
            CALL_OUT,
            RRSS
        }

    
}
